package com.jaketv.jaketvapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.model.people.Person;
import com.jaketv.jaketvapp.googleplus.GooglePlusAPI;
import com.jaketv.jaketvapp.googleplus.GooglePlusInterface;
import com.jaketv.jaketvapp.googleplus.Method;
import com.jaketv.jaketvapp.util.Constant;
import com.jaketv.jaketvapp.util.Util;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.InjectView;
import butterknife.OnClick;

public class LoginActivity extends BaseActivity {

    @InjectView(R.id.etEmail)
    EditText etEmail;
    @InjectView(R.id.etPassword)
    EditText etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if (read(Constant.SHRED_PR.KEY_IS_LOGGEDIN).equals("1")) {
            startActivity(HomeActivity.class);
            finish();
        }
        new GooglePlusAPI();
        GooglePlusAPI.getInstance().init(this);

        Typeface mFont = Typeface.createFromAsset(getAssets(), "roboto_regular.ttf");
        ViewGroup root = (ViewGroup) findViewById(R.id.rlMain);
        Util.setFont(root, mFont);

//        etEmail.setText("bhaviksadiwala@gmail.com");
//        etPassword.setText("123");

    }

    @OnClick(R.id.rlSignIn)
    @SuppressWarnings("unused")
    public void SignIn(View view) {
        hideKeyboard();
        if (isValidate()) {
            if (Util.isOnline(getApplicationContext()))
                new LogIn(getText(etEmail), getText(etPassword)).execute();
            else toast(Constant.network_error);
        }
    }

    @OnClick(R.id.rlGoogle)
    @SuppressWarnings("unused")
    public void SignInGooglePlus(View view) {
        hideKeyboard();
        if (Util.isOnline(getApplicationContext())){
            GooglePlusAPI.getInstance().getPersonInformation(Method.PROFILE, new GooglePlusInterface() {
                @Override
                public void getMyProfile(Person person) {
                    Log.e("TAG", "display name : " + person.getDisplayName());
                    Log.e("TAG", "id : " + person.getId());
                    Log.e("TAG", "name : " + person.getName());
                    String email1 = Plus.AccountApi.getAccountName(GooglePlusAPI.getInstance().getGoogleApiClient());
                    Log.e("TAG", "email : " + email1);

                    try {
                        JSONObject jsonObject = new JSONObject("" + person.getName());
                        String firstName = jsonObject.optString("givenName");
                        String lastName = jsonObject.optString("familyName");
                        String email = Plus.AccountApi.getAccountName(GooglePlusAPI.getInstance().getGoogleApiClient());
                        String googleid = "" + person.getId();

                        if (Util.isOnline(getApplicationContext()))
                            new Register(firstName, lastName, email, googleid).execute();
                        else toast(Constant.network_error);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }

            });

        }
//            new getProfileInfo().execute();
        else toast(Constant.network_error);
    }

    @OnClick(R.id.rlForgotPassword)
    @SuppressWarnings("unused")
    public void ForgotPassword(View view) {
        startActivity(ForgotPasswordActivity.class);
    }

    @OnClick(R.id.rlRegister)
    @SuppressWarnings("unused")
    public void Register(View view) {
        startActivity(RegisterActivity.class);
    }

    private boolean isValidate() {
        if (android.util.Patterns.EMAIL_ADDRESS.matcher(getText(etEmail)).matches() == false) {
            toast("please enter valid email");
            return false;
        }
        if (isEmpty(getText(etPassword))) {
            toast("please enter password");
            return false;
        }
        return true;
    }


    class getProfileInfo extends AsyncTask<Void, Void, Void> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(LoginActivity.this, R.style.MyTheme);
            progressDialog.setCancelable(false);
            progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            GooglePlusAPI.getInstance().getPersonInformation(Method.PROFILE, new GooglePlusInterface() {
                @Override
                public void getMyProfile(Person person) {
                    Log.e("TAG", "display name : " + person.getDisplayName());
                    Log.e("TAG", "id : " + person.getId());
                    Log.e("TAG", "name : " + person.getName());
                    String email1 = Plus.AccountApi.getAccountName(GooglePlusAPI.getInstance().getGoogleApiClient());
                    Log.e("TAG", "email : " + email1);

                    try {
                        JSONObject jsonObject = new JSONObject("" + person.getName());
                        String firstName = jsonObject.optString("givenName");
                        String lastName = jsonObject.optString("familyName");
                        String email = Plus.AccountApi.getAccountName(GooglePlusAPI.getInstance().getGoogleApiClient());
                        String googleid = "" + person.getId();

                        if (Util.isOnline(getApplicationContext()))
                            new Register(firstName, lastName, email, googleid).execute();
                        else toast(Constant.network_error);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }

            });

            return null;
        }

        @Override
        protected void onPostExecute(Void person) {
            super.onPostExecute(person);

            if (progressDialog != null) {
                if (progressDialog.isShowing()) progressDialog.dismiss();
            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GooglePlusAPI.SIGN_IN) {
            GooglePlusAPI.getInstance().connect();
        }
    }

    class LogIn extends AsyncTask<Void, String, String> {

        String email, password;
        ProgressDialog progressDialog;
        String response;

        public LogIn(String email, String password) {
            this.email = email;
            this.password = password;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(LoginActivity.this, R.style.MyTheme);
            progressDialog.setCancelable(false);
            progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
            progressDialog.show();
        }


        @Override
        protected String doInBackground(Void... params) {


            try {
                JSONObject jData = new JSONObject();
                jData.put("method", "Login");
                jData.put("email", email);
                jData.put("password", password);

                List<NameValuePair> params1 = new ArrayList<NameValuePair>(2);
                params1.add(new BasicNameValuePair("data", jData.toString()));
                response = Util.makeServiceCall(Constant.URL, 1, params1);
                Log.e("params1", ">>" + params1);

                Log.e("** response is:- ", ">>" + response);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return response;
        }

        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);

            if (progressDialog != null) {
                if (progressDialog.isShowing()) progressDialog.dismiss();
            }

            try {
                JSONObject jObj = new JSONObject(result);
                int status = jObj.optInt("success");

                if (status == 1) {
                    write(Constant.SHRED_PR.KEY_USERID, "" + jObj.optString("userid"));
                    write(Constant.SHRED_PR.KEY_IS_LOGGEDIN, "1");
                    startActivity(HomeActivity.class);
                    finish();
                } else toast(jObj.optString("msg"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class Register extends AsyncTask<Void, String, String> {

        String fname, lname, email, googleid;

        public Register(String fname, String lname, String email, String googleid) {
            this.fname = fname;
            this.lname = lname;
            this.email = email;
            this.googleid = googleid;
        }

        ProgressDialog progressDialog;
        String response;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            progressDialog = new ProgressDialog(LoginActivity.this, R.style.MyTheme);
//            progressDialog.setCancelable(false);
//            progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
//            progressDialog.show();

            progressDialog = ProgressDialog.show(LoginActivity.this, null,
                    "Loading...	", true, true);
        }


        @Override
        protected String doInBackground(Void... params) {


            try {
                JSONObject jData = new JSONObject();
                jData.put("method", "Registration");
                jData.put("userid", "0");
                jData.put("googleplusid", googleid);
                jData.put("fname", fname);
                jData.put("lname", lname);
                jData.put("email", email);
                jData.put("password", "");
                jData.put("picture", "");

                List<NameValuePair> params1 = new ArrayList<NameValuePair>(2);
                params1.add(new BasicNameValuePair("data", jData.toString()));
                response = Util.makeServiceCall(Constant.URL, 1, params1);
                Log.e("params1", ">>" + params1);

                Log.e("** response is:- ", ">>" + response);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return response;
        }

        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);

            if (progressDialog != null) {
                if (progressDialog.isShowing()) progressDialog.dismiss();
            }

            try {
                JSONObject jObj = new JSONObject(result);
                int status = jObj.optInt("success");

                if (status == 1) {
                    write(Constant.SHRED_PR.KEY_USERID, "" + jObj.optString("userid"));
                    write(Constant.SHRED_PR.KEY_IS_LOGGEDIN, "1");
                    startActivity(HomeActivity.class);
                    finish();
                } else toast(jObj.optString("msg"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
