package com.jaketv.jaketvapp.googleplus;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.model.people.Person;

public class GooglePlusAPI {


    public static final int SIGN_IN = 1001;
    public static final int SHARE = 1002;
    private static GooglePlusAPI instance;
    private GoogleApiClient googleApiClient;
    private Method currentMethod;
    private GooglePlusInterface googlePlusInterface;
    private Intent intent;

    public GooglePlusAPI() {
        instance = this;
    }

    public static GooglePlusAPI getInstance() {
        return GooglePlusAPI.instance;
    }

    public final void init(final Activity context) {

        googleApiClient = new GoogleApiClient.Builder(context).addConnectionCallbacks(new GoogleApiClient.ConnectionCallbacks() {
            @Override
            public void onConnected(Bundle bundle) {
                switch (currentMethod) {
                    case PROFILE:
                        getPersonInformation(currentMethod, googlePlusInterface);
                        break;
                    case SHARE:
                        share(context, currentMethod, intent);
                        break;
                }
            }

            @Override
            public void onConnectionSuspended(int i) {

            }
        }).addOnConnectionFailedListener(new GoogleApiClient.OnConnectionFailedListener() {
            @Override
            public void onConnectionFailed(ConnectionResult connectionResult) {
                try {
                    Log.e("onConnectionFailed",connectionResult.toString());
                    connectionResult.startResolutionForResult(context, SIGN_IN);
                } catch (IntentSender.SendIntentException e) {
                    // The intent was canceled before it was sent.  Return to the default
                    // state and attempt to connect to get an updated ConnectionResult.
                    e.printStackTrace();
                    googleApiClient.connect();
                }
            }
        }).addApi(Plus.API).addScope(Plus.SCOPE_PLUS_PROFILE).build();

    }

    public final void connect() {
        if (googleApiClient != null && !googleApiClient.isConnected()) {
            googleApiClient.connect();
        }
    }

    public final void disconnect() {
        if (googleApiClient != null && googleApiClient.isConnected()) {
            Plus.AccountApi.clearDefaultAccount(googleApiClient);
            googleApiClient.disconnect();
            instance = null;
        }
    }


    public void getPersonInformation(final Method method, GooglePlusInterface googlePlusInterface) {
        this.currentMethod = method;
        Log.e("method",""+method);
        this.googlePlusInterface = googlePlusInterface;
        if (googleApiClient.isConnected() && Plus.PeopleApi.getCurrentPerson(googleApiClient) != null) {
            Person person = Plus.PeopleApi.getCurrentPerson(googleApiClient);
            Log.e("person",""+person);
            googlePlusInterface.getMyProfile(person);
        } else {
            connect();
        }

    }

    public GoogleApiClient getGoogleApiClient() {
        return googleApiClient;
    }

    public void share(Activity activity, Method method, Intent intent) {
        currentMethod = method;
        this.intent = intent;
        if (googleApiClient.isConnected()) {
            activity.startActivityForResult(intent, SHARE);
        } else {
            connect();
        }

    }
}
