/*
 * Copyright (c) 2015. $user
 */

package com.jaketv.jaketvapp.googleplus;

import com.google.android.gms.plus.model.people.Person;

/**
 * Created by Ahesanali Khanusiya on 20/4/15.
 */

/**
 * Used for getting user profile detail using Google plus.
 */
public interface GooglePlusInterface {
    /**
     * @param person All profile detail which is provided by google plus.
     */
    void getMyProfile(Person person);
}
